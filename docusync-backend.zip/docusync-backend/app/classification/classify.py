"""
Step 5 — Classification (EfficientNet-B0, transfer learning).

TODO: replace classify_document() with a real inference call:
    from torchvision import models, transforms
    model = load_your_finetuned_efficientnet_b0()
    tensor = transform(Image.open(image_path)).unsqueeze(0)
    logits = model(tensor)
    probs = torch.softmax(logits, dim=1)
    label_idx = probs.argmax().item()
    confidence = probs.max().item()
    return LABELS[label_idx], confidence

Keep the same return shape — (document_type: str, confidence: float) —
and nothing calling this function needs to change.
"""
from typing import Tuple

KNOWN_TYPES = ["id_proof", "marksheet", "fee_receipt", "other"]


def classify_document(image_path: str) -> Tuple[str, float]:
    """
    Predict the document type from a preprocessed image.

    Returns:
        (document_type, confidence) — confidence in the range 0.0-1.0.
    """
    # STUB: always returns "other" with high confidence so the pipeline
    # can complete end-to-end before the real model is plugged in.
    return "other", 0.95
