"""
Steps 3, 13, 15 — Upload endpoint, HITL routing endpoints, status/search
endpoints. This is the only file the frontend actually talks to; every
route here is thin on purpose and delegates to storage/ and pipeline.py.
"""
import os
import shutil

from fastapi import APIRouter, UploadFile, File, BackgroundTasks, Depends, HTTPException
from sqlalchemy.orm import Session

from app.config import UPLOAD_DIR
from app.database import get_db
from app.pipeline import run_pipeline
from app.storage import record_store
from app.schemas import UploadResponse, DocumentStatus, ReviewDecisionRequest

router = APIRouter(prefix="/api", tags=["documents"])


@router.post("/documents/upload", response_model=UploadResponse)
def upload_document(
    background_tasks: BackgroundTasks,
    file: UploadFile = File(...),
    db: Session = Depends(get_db),
):
    """
    Step 3 — accepts the file, saves it, creates the record, and returns
    immediately with status "received". The rest of the pipeline runs in
    the background so the caller (the frontend) never has to block on it.
    """
    record_id_placeholder = os.urandom(6).hex()
    stored_path = os.path.join(UPLOAD_DIR, f"{record_id_placeholder}_{file.filename}")

    with open(stored_path, "wb") as out_file:
        shutil.copyfileobj(file.file, out_file)

    record = record_store.create_record(db, filename=file.filename, stored_path=stored_path)

    background_tasks.add_task(run_pipeline, record.id)

    return UploadResponse(id=record.id, status=record.status, original_filename=record.original_filename)


@router.get("/documents/{record_id}/status", response_model=DocumentStatus)
def get_status(record_id: str, db: Session = Depends(get_db)):
    """Step 15 — the frontend polls this to show live pipeline progress."""
    record = record_store.get_record(db, record_id)
    if record is None:
        raise HTTPException(status_code=404, detail="Document not found.")
    return DocumentStatus.from_record(record)


@router.get("/documents", response_model=list[DocumentStatus])
def list_documents(limit: int = 100, db: Session = Depends(get_db)):
    """Step 15 — backs the record search screen."""
    records = record_store.list_records(db, limit=limit)
    return [DocumentStatus.from_record(r) for r in records]


@router.get("/review-queue", response_model=list[DocumentStatus])
def review_queue(db: Session = Depends(get_db)):
    """Step 13 — every record currently waiting on a human decision."""
    records = record_store.list_needs_review(db)
    return [DocumentStatus.from_record(r) for r in records]


@router.post("/review/{record_id}/decision", response_model=DocumentStatus)
def submit_review_decision(record_id: str, body: ReviewDecisionRequest, db: Session = Depends(get_db)):
    """
    Step 13 — an admin approves, corrects, or rejects a flagged record.
    Approval/correction routes through the same finalize_record() used by
    the automatic path, so "processed" always means the same thing.
    """
    record = record_store.get_record(db, record_id)
    if record is None:
        raise HTTPException(status_code=404, detail="Document not found.")
    if body.decision not in ("approved", "corrected", "rejected"):
        raise HTTPException(status_code=400, detail="decision must be approved, corrected, or rejected.")

    record_store.apply_review_decision(
        db, record, decision=body.decision, reviewed_by=body.reviewed_by, corrected_fields=body.corrected_fields
    )
    return DocumentStatus.from_record(record)
