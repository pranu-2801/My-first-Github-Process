"""
Step 8 — Entity resolution (XGBoost).

TODO: replace resolve_entity() with a real call:
    features = build_feature_vector(fields, candidate_students)
    match_probs = xgb_model.predict_proba(features)
    best_idx = match_probs[:, 1].argmax()
    return candidate_students[best_idx].id, float(match_probs[best_idx, 1])

The confidence returned here is what decides whether this record goes
to Human-in-the-Loop review (see config.ENTITY_MATCH_CONFIDENCE_THRESHOLD).
"""
from typing import Optional, Tuple, Dict


def resolve_entity(fields: Dict[str, str]) -> Tuple[Optional[str], float]:
    """
    Match extracted fields to an existing student/entity record.

    Returns:
        (entity_id, confidence) — entity_id is None if no match was found.
    """
    # STUB: no real student database to match against yet.
    if fields.get("roll_no"):
        return f"student-{fields['roll_no']}", 0.90
    return None, 0.0
