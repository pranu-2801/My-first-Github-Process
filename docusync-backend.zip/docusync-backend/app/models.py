"""
The record shape. Every pipeline stage fills in a bit more of this row
as the document moves through it — this is why the storage layer was
built first (Step 2): every later step just needs to know what already
exists here.
"""
import uuid
from datetime import datetime, timezone

from sqlalchemy import Column, String, Float, Boolean, DateTime, Text

from app.database import Base


def _new_id() -> str:
    return uuid.uuid4().hex[:12]


class DocumentRecord(Base):
    __tablename__ = "documents"

    id = Column(String, primary_key=True, default=_new_id)

    # --- upload (Step 3) ---
    original_filename = Column(String, nullable=False)
    stored_path = Column(String, nullable=False)
    created_at = Column(DateTime, default=lambda: datetime.now(timezone.utc))

    # status tracks exactly which pipeline stage this record is at.
    # One of: received, preprocessing, preprocessed, classifying, classified,
    #         extracting_text, ocr_done, extracting_fields, extracted,
    #         resolving_entity, entity_resolved, checking_duplicate, deduped,
    #         scoring_risk, risk_scored, policy_checking, needs_review,
    #         processed, rejected
    status = Column(String, default="received", index=True)

    # --- preprocessing (Step 4) ---
    preprocessed_path = Column(String, nullable=True)

    # --- classification (Step 5) ---
    document_type = Column(String, nullable=True)
    classification_confidence = Column(Float, nullable=True)

    # --- OCR (Step 6) ---
    raw_text = Column(Text, nullable=True)

    # --- extraction / PII flags (Step 7) ---
    extracted_fields_json = Column(Text, nullable=True)   # JSON string
    pii_fields_json = Column(Text, nullable=True)          # JSON string: list of field names flagged as PII

    # --- entity resolution (Step 8) ---
    matched_entity_id = Column(String, nullable=True)
    match_confidence = Column(Float, nullable=True)

    # --- deduplication (Step 9) ---
    is_duplicate = Column(Boolean, default=False)
    duplicate_of_id = Column(String, nullable=True)
    doc_hash = Column(String, nullable=True)

    # --- risk assessment (Step 10) ---
    risk_score = Column(Float, nullable=True)

    # --- policy / decision gate (Step 11 + 12) ---
    policy_decision = Column(String, nullable=True)   # "pass" | "masked_pass" | "needs_review" | "rejected"
    policy_reason = Column(String, nullable=True)
    masked_fields_json = Column(Text, nullable=True)   # JSON string: {field: masked_value}

    # --- final state (Step 14) ---
    processed = Column(Boolean, default=False)

    # --- HITL (Step 13) ---
    review_reason = Column(String, nullable=True)
    review_decision = Column(String, nullable=True)   # "approved" | "corrected" | "rejected"
    reviewed_by = Column(String, nullable=True)
