"""
Runs every pipeline stage in order for one record. This is what turns the
architecture diagram into code — each line below is one box in the
diagram, called in the same order:

    OpenCV -> EfficientNet-B0 -> EasyOCR -> NLP/Regex -> XGBoost
           -> Dedup -> LightGBM -> Rule Engine -> (store or HITL)

Runs as a FastAPI BackgroundTask, so the upload endpoint can return
immediately instead of making the caller wait for the whole pipeline.
"""
import os

from app.config import (
    CLASSIFICATION_CONFIDENCE_THRESHOLD,
    ENTITY_MATCH_CONFIDENCE_THRESHOLD,
    UPLOAD_DIR,
)
from app.database import SessionLocal
from app.storage import record_store
from app.preprocessing.preprocess import preprocess_image
from app.classification.classify import classify_document
from app.ocr.extract_text import run_ocr
from app.extraction.extract_fields import extract_fields
from app.entity_resolution.resolve import resolve_entity
from app.dedup.dedup import compute_hash, is_likely_duplicate
from app.risk.risk_score import compute_risk_score
from app.policy.policy_engine import evaluate_policy


def run_pipeline(record_id: str) -> None:
    """Entry point called by the upload endpoint's background task."""
    db = SessionLocal()
    try:
        record = record_store.get_record(db, record_id)
        if record is None:
            return

        # Step 4 — Preprocessing
        record_store.set_status(db, record, "preprocessing")
        preprocessed_path = os.path.join(UPLOAD_DIR, f"{record.id}_preprocessed.png")
        preprocess_image(record.stored_path, preprocessed_path)
        record_store.save_preprocessing_result(db, record, preprocessed_path)

        # Step 5 — Classification
        record_store.set_status(db, record, "classifying")
        doc_type, class_confidence = classify_document(preprocessed_path)
        record_store.save_classification_result(db, record, doc_type, class_confidence)
        if class_confidence < CLASSIFICATION_CONFIDENCE_THRESHOLD:
            record_store.send_to_review(db, record, "Low-confidence document classification.")
            return

        # Step 6 — OCR
        record_store.set_status(db, record, "extracting_text")
        raw_text = run_ocr(preprocessed_path)
        record_store.save_ocr_result(db, record, raw_text)

        # Step 7 — Information / PII extraction
        record_store.set_status(db, record, "extracting_fields")
        fields, pii_fields = extract_fields(raw_text)
        record_store.save_extraction_result(db, record, fields, pii_fields)

        # Step 8 — Entity resolution
        record_store.set_status(db, record, "resolving_entity")
        entity_id, match_confidence = resolve_entity(fields)
        record_store.save_entity_resolution_result(db, record, entity_id, match_confidence)
        if entity_id and match_confidence < ENTITY_MATCH_CONFIDENCE_THRESHOLD:
            record_store.send_to_review(db, record, "Low-confidence entity match.")
            return

        # Step 9 — Deduplication
        record_store.set_status(db, record, "checking_duplicate")
        doc_hash = compute_hash(preprocessed_path)
        is_duplicate, duplicate_of_id = _check_duplicate(db, record.id, doc_hash)
        record_store.save_dedup_result(db, record, doc_hash, is_duplicate, duplicate_of_id)

        # Step 10 — Risk assessment
        record_store.set_status(db, record, "scoring_risk")
        risk_score = compute_risk_score(
            classification_confidence=class_confidence,
            match_confidence=match_confidence or 0.0,
            pii_field_count=len(pii_fields),
            is_duplicate=is_duplicate,
        )
        record_store.save_risk_result(db, record, risk_score)

        # Step 11 + 12 — Policy gate + masking (never ML, always auditable)
        record_store.set_status(db, record, "policy_checking")
        decision, reason, masked_fields = evaluate_policy(fields, pii_fields, risk_score, is_duplicate)
        record_store.save_policy_result(db, record, decision, reason, masked_fields)

        # Step 13 — HITL routing
        if decision == "needs_review":
            record_store.send_to_review(db, record, reason)
            return
        if decision == "rejected":
            record_store.set_status(db, record, "rejected")
            return

        # Step 14 — Final storage write. This is the ONLY place (besides
        # the HITL approval path) that ever marks a record processed.
        record_store.finalize_record(db, record)

    finally:
        db.close()


def _check_duplicate(db, current_record_id: str, doc_hash: str):
    """Compare this record's hash against every previously stored hash."""
    for other in record_store.list_records(db, limit=500):
        if other.id == current_record_id or not other.doc_hash:
            continue
        if is_likely_duplicate(doc_hash, other.doc_hash):
            return True, other.id
    return False, None
