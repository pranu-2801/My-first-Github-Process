"""
Every read/write to a document record goes through here. Keeping this in
one place means the final "write as processed" rule (Step 14 — only one
function should ever mark a record processed) is easy to enforce and easy
to find.
"""
import json
from typing import Optional
from sqlalchemy.orm import Session

from app.models import DocumentRecord


def create_record(db: Session, filename: str, stored_path: str) -> DocumentRecord:
    record = DocumentRecord(
        original_filename=filename,
        stored_path=stored_path,
        status="received",
    )
    db.add(record)
    db.commit()
    db.refresh(record)
    return record


def get_record(db: Session, record_id: str) -> Optional[DocumentRecord]:
    return db.get(DocumentRecord, record_id)


def list_records(db: Session, limit: int = 100):
    return (
        db.query(DocumentRecord)
        .order_by(DocumentRecord.created_at.desc())
        .limit(limit)
        .all()
    )


def list_needs_review(db: Session):
    return (
        db.query(DocumentRecord)
        .filter(DocumentRecord.status == "needs_review")
        .order_by(DocumentRecord.created_at.asc())
        .all()
    )


def set_status(db: Session, record: DocumentRecord, status: str) -> None:
    record.status = status
    db.commit()


def send_to_review(db: Session, record: DocumentRecord, reason: str) -> None:
    record.status = "needs_review"
    record.review_reason = reason
    db.commit()


def save_preprocessing_result(db: Session, record: DocumentRecord, preprocessed_path: str) -> None:
    record.preprocessed_path = preprocessed_path
    record.status = "preprocessed"
    db.commit()


def save_classification_result(db: Session, record: DocumentRecord, doc_type: str, confidence: float) -> None:
    record.document_type = doc_type
    record.classification_confidence = confidence
    record.status = "classified"
    db.commit()


def save_ocr_result(db: Session, record: DocumentRecord, raw_text: str) -> None:
    record.raw_text = raw_text
    record.status = "ocr_done"
    db.commit()


def save_extraction_result(db: Session, record: DocumentRecord, fields: dict, pii_fields: list) -> None:
    record.extracted_fields_json = json.dumps(fields)
    record.pii_fields_json = json.dumps(pii_fields)
    record.status = "extracted"
    db.commit()


def save_entity_resolution_result(db: Session, record: DocumentRecord, entity_id: Optional[str], confidence: float) -> None:
    record.matched_entity_id = entity_id
    record.match_confidence = confidence
    record.status = "entity_resolved"
    db.commit()


def save_dedup_result(db: Session, record: DocumentRecord, doc_hash: str, is_duplicate: bool, duplicate_of_id: Optional[str]) -> None:
    record.doc_hash = doc_hash
    record.is_duplicate = is_duplicate
    record.duplicate_of_id = duplicate_of_id
    record.status = "deduped"
    db.commit()


def save_risk_result(db: Session, record: DocumentRecord, risk_score: float) -> None:
    record.risk_score = risk_score
    record.status = "risk_scored"
    db.commit()


def save_policy_result(db: Session, record: DocumentRecord, decision: str, reason: str, masked_fields: dict) -> None:
    record.policy_decision = decision
    record.policy_reason = reason
    record.masked_fields_json = json.dumps(masked_fields) if masked_fields else None
    db.commit()


def finalize_record(db: Session, record: DocumentRecord) -> None:
    """
    The ONE place a record is ever marked processed. Every path through the
    pipeline — automatic pass or HITL approval — must call this and only
    this, so "final record" always means the same thing (see Step 14).
    """
    record.processed = True
    record.status = "processed"
    db.commit()


def apply_review_decision(db: Session, record: DocumentRecord, decision: str, reviewed_by: str, corrected_fields: Optional[dict]) -> None:
    record.review_decision = decision
    record.reviewed_by = reviewed_by
    if corrected_fields:
        existing = json.loads(record.extracted_fields_json) if record.extracted_fields_json else {}
        existing.update(corrected_fields)
        record.extracted_fields_json = json.dumps(existing)

    if decision in ("approved", "corrected"):
        finalize_record(db, record)
    else:  # rejected
        record.status = "rejected"
        db.commit()
