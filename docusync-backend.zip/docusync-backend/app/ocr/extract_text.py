"""
Step 6 — OCR (EasyOCR).

TODO: replace run_ocr() with a real call:
    import easyocr
    reader = easyocr.Reader(['en'])
    results = reader.readtext(image_path, detail=0)
    return "\n".join(results)

This is usually the fastest real stage to wire in, since EasyOCR is a
plug-in library call rather than a model you have to train yourself.
"""


def run_ocr(image_path: str) -> str:
    """
    Extract raw text from a preprocessed document image.

    Returns:
        The raw extracted text as a single string.
    """
    # STUB: no OCR yet, so return a placeholder that downstream stages
    # can still parse without crashing.
    return "SAMPLE TEXT: Name: Jane Doe  RollNo: 12A345  DOB: 01-01-2000  Amount: 5000"
