"""
Step 11 — Policy / decision gate (deterministic rule engine)
Step 12 — Masking (called INSIDE the gate, before storage — never after)

This is the one pipeline stage that is intentionally never an ML model.
Per the plan, compliance decisions must stay auditable and explainable,
so every decision here is a plain if/else that can be traced back to
exactly which rule fired — that traceability is the whole point.
"""
from typing import Dict, List, Tuple

from app.config import RISK_REVIEW_THRESHOLD


def mask_value(value: str) -> str:
    """Mask all but the last 4 characters, e.g. Aadhaar -> XXXX-XXXX-1234."""
    value = value.strip()
    if len(value) <= 4:
        return "X" * len(value)
    visible = value[-4:]
    hidden = "X" * (len(value) - 4)
    return f"{hidden}{visible}"


def evaluate_policy(
    fields: Dict[str, str],
    pii_fields: List[str],
    risk_score: float,
    is_duplicate: bool,
) -> Tuple[str, str, Dict[str, str]]:
    """
    Apply deterministic rules and decide what happens to this record.

    Returns:
        (decision, reason, masked_fields)
        decision is one of: "pass", "masked_pass", "needs_review", "rejected"
    """
    masked_fields: Dict[str, str] = {}

    # Rule 1 — exact duplicates are rejected outright, never stored twice.
    if is_duplicate:
        return "rejected", "Document matches an existing submission (deduplication).", masked_fields

    # Rule 2 — high combined risk always goes to a human, regardless of
    # whether any single PII rule fired.
    if risk_score >= RISK_REVIEW_THRESHOLD:
        return "needs_review", f"Risk score {risk_score} is at or above the review threshold.", masked_fields

    # Rule 3 — any detected PII gets masked before the record can be
    # finalized. This is the "masking as a storage gate" requirement —
    # it happens here, before storage, never as a cleanup step after.
    if pii_fields:
        for field_name in pii_fields:
            if field_name in fields:
                masked_fields[field_name] = mask_value(fields[field_name])
        return "masked_pass", f"Sensitive fields masked: {', '.join(pii_fields)}.", masked_fields

    # Rule 4 — nothing flagged, low risk: the record passes as-is.
    return "pass", "No policy violations detected.", masked_fields
