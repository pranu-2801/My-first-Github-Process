"""
Pydantic schemas — shape of the JSON the API sends back. Kept separate
from models.py (the DB table) on purpose: the frontend should never see
internal-only fields, and this is the one place that decides what it does see.
"""
import json
from datetime import datetime
from typing import Optional, List

from pydantic import BaseModel, ConfigDict


class UploadResponse(BaseModel):
    id: str
    status: str
    original_filename: str


class DocumentStatus(BaseModel):
    model_config = ConfigDict(from_attributes=True)

    id: str
    original_filename: str
    status: str
    created_at: datetime

    document_type: Optional[str] = None
    classification_confidence: Optional[float] = None

    extracted_fields: Optional[dict] = None
    pii_fields: Optional[List[str]] = None

    matched_entity_id: Optional[str] = None
    match_confidence: Optional[float] = None

    is_duplicate: bool = False
    duplicate_of_id: Optional[str] = None

    risk_score: Optional[float] = None

    policy_decision: Optional[str] = None
    policy_reason: Optional[str] = None
    masked_fields: Optional[dict] = None

    processed: bool = False
    review_reason: Optional[str] = None

    @classmethod
    def from_record(cls, record):
        """Build this schema from a DocumentRecord row, parsing its JSON columns."""
        return cls(
            id=record.id,
            original_filename=record.original_filename,
            status=record.status,
            created_at=record.created_at,
            document_type=record.document_type,
            classification_confidence=record.classification_confidence,
            extracted_fields=json.loads(record.extracted_fields_json) if record.extracted_fields_json else None,
            pii_fields=json.loads(record.pii_fields_json) if record.pii_fields_json else None,
            matched_entity_id=record.matched_entity_id,
            match_confidence=record.match_confidence,
            is_duplicate=bool(record.is_duplicate),
            duplicate_of_id=record.duplicate_of_id,
            risk_score=record.risk_score,
            policy_decision=record.policy_decision,
            policy_reason=record.policy_reason,
            masked_fields=json.loads(record.masked_fields_json) if record.masked_fields_json else None,
            processed=bool(record.processed),
            review_reason=record.review_reason,
        )


class ReviewDecisionRequest(BaseModel):
    decision: str   # "approved" | "corrected" | "rejected"
    reviewed_by: str = "admin"
    corrected_fields: Optional[dict] = None
