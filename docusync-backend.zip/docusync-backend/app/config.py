"""
Central settings for the pipeline.

Keeping every tunable value here means a later step (env vars, a config
file, a settings UI) only has to change this one place.
"""
import os

BASE_DIR = os.path.dirname(os.path.dirname(os.path.abspath(__file__)))

# Where uploaded files are saved.
UPLOAD_DIR = os.path.join(BASE_DIR, "uploads")
os.makedirs(UPLOAD_DIR, exist_ok=True)

# SQLite for the MVP storage layer. Swap this for a real DB URL later
# (e.g. "postgresql://user:pass@host/dbname") — nothing else has to change,
# since every read/write goes through app/storage/record_store.py.
DATABASE_URL = f"sqlite:///{os.path.join(BASE_DIR, 'docusync.db')}"

# Confidence thresholds — anything below these gets routed to the
# Human-in-the-Loop review queue instead of continuing automatically.
CLASSIFICATION_CONFIDENCE_THRESHOLD = 0.60
ENTITY_MATCH_CONFIDENCE_THRESHOLD = 0.60

# Risk score (0.0 - 1.0) above which the policy engine sends a record
# for manual review even if no PII rule was directly violated.
RISK_REVIEW_THRESHOLD = 0.75

# Field names the rule-based PII detector looks for. Extend this list
# as the real NLP/Regex extraction stage (Step 7) gets built out.
PII_FIELD_NAMES = {"aadhaar", "bank_account", "pan"}
