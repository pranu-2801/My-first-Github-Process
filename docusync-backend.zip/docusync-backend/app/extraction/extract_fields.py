"""
Step 7 — Information / PII extraction (NLP + Regex).

Per the tech plan, this stage is rule-based, not a trained model — so
unlike the other stages this one is REAL logic already, not a stub.
Extend the regex patterns as you meet more document formats; the field
names and PII flags feed directly into the policy engine.
"""
import re
from typing import Tuple, Dict, List

FIELD_PATTERNS = {
    "name": r"Name:\s*([A-Za-z .]+)",
    "roll_no": r"RollNo:\s*([A-Za-z0-9]+)",
    "dob": r"DOB:\s*([\d/-]+)",
    "amount": r"Amount:\s*([\d,.]+)",
    "aadhaar": r"\b(\d{4}[- ]?\d{4}[- ]?\d{4})\b",
    "bank_account": r"\b(?:A/C|Account)\s*(?:No\.?)?:?\s*(\d{9,18})\b",
}

# Which of the fields above should be treated as PII once found.
PII_FIELD_NAMES = {"aadhaar", "bank_account"}


def extract_fields(raw_text: str) -> Tuple[Dict[str, str], List[str]]:
    """
    Parse OCR text into structured fields, and separately flag which of
    those fields are sensitive (PII).

    Returns:
        (fields, pii_field_names) — fields is a dict of everything found,
        pii_field_names is the subset of its keys that are sensitive.
    """
    fields: Dict[str, str] = {}
    for field_name, pattern in FIELD_PATTERNS.items():
        match = re.search(pattern, raw_text, flags=re.IGNORECASE)
        if match:
            fields[field_name] = match.group(1).strip()

    pii_found = [name for name in fields if name in PII_FIELD_NAMES]
    return fields, pii_found
