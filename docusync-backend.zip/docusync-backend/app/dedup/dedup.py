"""
Step 9 — Deduplication (perceptual hashing).

Per the tech plan this needs no trained model, so this one is real,
working logic already — a simple average-hash (aHash) implemented with
Pillow. It can run and be tested completely independently of every ML
stage, which is exactly why the plan calls it out as a good one to build
and test in isolation.

For production, swap this for the `imagehash` package (perceptual/
difference hash is more robust than average hash) — the function
signature below stays the same either way.
"""
from PIL import Image


def compute_hash(image_path: str) -> str:
    """
    Compute a simple 64-bit average hash for an image, returned as a
    hex string. Visually similar images produce hashes that differ in
    only a few bits.
    """
    img = Image.open(image_path).convert("L").resize((8, 8))
    pixels = list(img.getdata())
    avg = sum(pixels) / len(pixels)
    bits = "".join("1" if p >= avg else "0" for p in pixels)
    return f"{int(bits, 2):016x}"


def hamming_distance(hash_a: str, hash_b: str) -> int:
    """Number of differing bits between two hex hash strings."""
    int_a, int_b = int(hash_a, 16), int(hash_b, 16)
    return bin(int_a ^ int_b).count("1")


def is_likely_duplicate(hash_a: str, hash_b: str, threshold: int = 5) -> bool:
    """
    Two images with a Hamming distance below the threshold (out of 64
    bits) are treated as duplicates or near-duplicates.
    """
    return hamming_distance(hash_a, hash_b) <= threshold
