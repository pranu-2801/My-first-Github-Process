"""
Step 4 — Preprocessing (OpenCV).

TODO: replace the body of preprocess_image() with real OpenCV calls:
    import cv2
    img = cv2.imread(input_path)
    img = cv2.resize(img, (1024, 1024))
    img = cv2.cvtColor(img, cv2.COLOR_BGR2GRAY)
    ... denoise / normalize ...
    cv2.imwrite(output_path, img)

Test this function on its own first (feed it a messy scanned image, check
the output looks clean) before it's wired into the rest of the pipeline —
that's the whole point of building each stage as its own file.
"""
import shutil


def preprocess_image(input_path: str, output_path: str) -> str:
    """
    Clean, resize and normalize a document image.

    Args:
        input_path: path to the raw uploaded file.
        output_path: where the cleaned image should be written.

    Returns:
        The output_path, for convenience.
    """
    # STUB: for now we just copy the file through untouched, so the rest
    # of the pipeline has something to work with.
    shutil.copy(input_path, output_path)
    return output_path
