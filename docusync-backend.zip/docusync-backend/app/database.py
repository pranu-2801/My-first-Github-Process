"""
SQLAlchemy engine + session. This is Step 2 of the build order —
the storage layer gets set up before any pipeline logic exists.
"""
from sqlalchemy import create_engine
from sqlalchemy.orm import sessionmaker, declarative_base

from app.config import DATABASE_URL

# check_same_thread=False is needed for SQLite when used from FastAPI's
# threaded background tasks. Not needed once you move to Postgres/MySQL.
engine = create_engine(
    DATABASE_URL, connect_args={"check_same_thread": False}
)
SessionLocal = sessionmaker(autocommit=False, autoflush=False, bind=engine)
Base = declarative_base()


def get_db():
    """FastAPI dependency — yields a DB session and always closes it."""
    db = SessionLocal()
    try:
        yield db
    finally:
        db.close()


def init_db():
    """Create all tables. Called once at app startup."""
    from app import models  # noqa: F401 (import so the table is registered)
    Base.metadata.create_all(bind=engine)
