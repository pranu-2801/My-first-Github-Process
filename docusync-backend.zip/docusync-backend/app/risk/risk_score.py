"""
Step 10 — Risk assessment (LightGBM).

TODO: replace compute_risk_score() with a real call:
    features = [classification_confidence, match_confidence,
                len(pii_fields), int(is_duplicate)]
    risk = lgbm_model.predict_proba([features])[0][1]
    return float(risk)

This stage naturally comes last among the ML stages because it depends
on the outputs of every stage before it — classification confidence,
match confidence, PII flags, and the duplicate check.
"""


def compute_risk_score(
    classification_confidence: float,
    match_confidence: float,
    pii_field_count: int,
    is_duplicate: bool,
) -> float:
    """
    Combine pipeline signals into a single probabilistic risk score.

    Returns:
        A risk score between 0.0 (low risk) and 1.0 (high risk).
    """
    # STUB: a simple weighted heuristic standing in for the trained
    # LightGBM model. Low confidence, more PII fields, and duplicates
    # all push the score up.
    score = 0.0
    score += (1 - classification_confidence) * 0.3
    score += (1 - match_confidence) * 0.3
    score += min(pii_field_count * 0.15, 0.3)
    score += 0.2 if is_duplicate else 0.0
    return round(min(score, 1.0), 3)
