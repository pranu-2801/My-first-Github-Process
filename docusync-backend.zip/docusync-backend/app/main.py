"""
Step 1 — FastAPI app entry point. Run with:
    uvicorn app.main:app --reload
Then open http://127.0.0.1:8000/docs
"""
from fastapi import FastAPI
from fastapi.middleware.cors import CORSMiddleware

from app.database import init_db
from app.api.documents import router as documents_router

app = FastAPI(
    title="DocuSync & DataTraceX API",
    description="Checkpoint-1 backend: upload -> classify -> extract -> policy check -> store.",
    version="0.1.0",
)

# Wide open for local development against the React dashboard on a
# different port. Tighten this to your actual frontend origin before
# deploying anywhere real.
app.add_middleware(
    CORSMiddleware,
    allow_origins=["*"],
    allow_methods=["*"],
    allow_headers=["*"],
)

app.include_router(documents_router)


@app.on_event("startup")
def on_startup():
    init_db()


@app.get("/")
def root():
    return {"service": "DocuSync & DataTraceX API", "status": "running", "docs": "/docs"}
