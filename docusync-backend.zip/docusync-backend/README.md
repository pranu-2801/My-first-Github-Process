# DocuSync & DataTraceX — Backend (Checkpoint-1 scaffold)

This is a **runnable skeleton** of the backend, covering Steps 1–3 of the
build order (project structure, storage layer, upload endpoint) with every
later pipeline stage (Steps 4–12) wired in as a **working stub** — so you
have one complete path running today:

```
upload → preprocess → classify → ocr → extract → entity-resolve
       → dedup → risk-score → policy gate (mask) → store as processed
```

Nothing here calls a real ML model yet. Each stage returns a clearly
labelled placeholder value and is isolated in its own file, so you can
swap in EfficientNet-B0 / EasyOCR / XGBoost / LightGBM one file at a time
without touching anything else — exactly the "extend, don't rebuild"
approach from the plan.

## Run it

```bash
python3 -m venv venv
source venv/bin/activate          # venv\Scripts\activate on Windows
pip install -r requirements.txt
uvicorn app.main:app --reload
```

Then open **http://127.0.0.1:8000/docs** — FastAPI's interactive Swagger
UI, so you can upload a file and watch it move through the pipeline
without building the frontend first.

## Folder structure

```
app/
  main.py                 FastAPI app, mounts the router
  config.py                Settings: upload dir, DB path, thresholds
  database.py               SQLAlchemy engine/session (SQLite file)
  models.py                  The DocumentRecord table — the record shape
  schemas.py                  Pydantic response shapes for the API

  api/
    documents.py             All HTTP endpoints (upload, status, list,
                              review queue, review decision)

  preprocessing/preprocess.py        Step 4  — TODO: OpenCV
  classification/classify.py          Step 5  — TODO: EfficientNet-B0
  ocr/extract_text.py                  Step 6  — TODO: EasyOCR
  extraction/extract_fields.py          Step 7  — TODO: NLP + Regex
  entity_resolution/resolve.py           Step 8  — TODO: XGBoost
  dedup/dedup.py                          Step 9  — TODO: perceptual hash
  risk/risk_score.py                       Step 10 — TODO: LightGBM
  policy/policy_engine.py                   Step 11+12 — rule engine +
                                             masking (this one is REAL
                                             logic already, not a stub —
                                             it's deterministic, not ML)

  storage/record_store.py    Small helper functions wrapping DB reads/writes
                              so the API layer never touches SQLAlchemy directly
```

## What's real vs. a stub, right now

| Piece | Status |
|---|---|
| Folder structure | ✅ matches the architecture diagram |
| Storage layer / record shape | ✅ real — SQLite via SQLAlchemy |
| Upload endpoint | ✅ real — saves the file, creates the record |
| Background pipeline runner | ✅ real — runs every stage in order |
| Preprocessing / Classification / OCR / Extraction / Entity resolution / Dedup / Risk | 🟡 stub — returns placeholder data so the pipeline completes end-to-end |
| Policy gate + masking | ✅ real — simple deterministic rules, no ML needed here by design |
| HITL review queue + decision endpoint | ✅ real |
| Status + search endpoints | ✅ real |

## Next steps, in order (matches the build plan)

1. Run it as-is first. Upload any file through `/docs` and watch the
   record move through every status in `GET /api/documents/{id}/status`.
2. Open `app/preprocessing/preprocess.py` and wire in real OpenCV calls.
3. Open `app/classification/classify.py` and load your fine-tuned
   EfficientNet-B0 model — keep the same function signature.
4. Repeat down the list in `README.md`'s folder table, one stage at a time.
   Because each stage is isolated, the rest of the pipeline keeps working
   while you upgrade one piece.
